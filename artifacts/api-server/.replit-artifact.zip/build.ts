import path from "path";
import { fileURLToPath } from "url";
import { build as esbuild } from "esbuild";
import { rm, readFile, cp, access } from "fs/promises";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// server deps to bundle to reduce openat(2) syscalls
// which helps cold start times without risking some
// packages that are not bundle compatible
const allowlist = [
  "@google/generative-ai",
  "axios",
  "bcryptjs",
  "connect-pg-simple",
  "cookie-parser",
  "cors",
  "date-fns",
  "drizzle-orm",
  "drizzle-zod",
  "express",
  "express-rate-limit",
  "express-session",
  "helmet",
  "jsonwebtoken",
  "memorystore",
  "multer",
  "nanoid",
  "nodemailer",
  "openai",
  "passport",
  "passport-local",
  "pg",
  "stripe",
  "uuid",
  "ws",
  "xlsx",
  "zod",
  "zod-validation-error",
];

async function buildAll() {
  const distDir = path.resolve(__dirname, "dist");
  await rm(distDir, { recursive: true, force: true });

  console.log("building server...");
  const pkgPath = path.resolve(__dirname, "package.json");
  const pkg = JSON.parse(await readFile(pkgPath, "utf-8"));
  const allDeps = [
    ...Object.keys(pkg.dependencies || {}),
    ...Object.keys(pkg.devDependencies || {}),
  ];
  const externals = allDeps.filter(
    (dep) =>
      !allowlist.includes(dep) &&
      !(pkg.dependencies?.[dep]?.startsWith("workspace:")),
  );

  await esbuild({
    entryPoints: [path.resolve(__dirname, "src/index.ts")],
    platform: "node",
    bundle: true,
    format: "cjs",
    outfile: path.resolve(distDir, "index.cjs"),
    define: {
      "process.env.NODE_ENV": '"production"',
      // Polyfill import.meta.url for CJS output so fileURLToPath() works correctly
      "import.meta.url": "__cjs_import_meta_url__",
    },
    // Inject import.meta.url shim at the top of the CJS bundle
    banner: {
      js: 'const __cjs_import_meta_url__ = require("url").pathToFileURL(__filename).href;',
    },
    minify: true,
    external: externals,
    logLevel: "info",
  });

  // Copy React frontend build into dist/public (for cPanel/standalone serving)
  const frontendDist = path.resolve(__dirname, "../../artifacts/smm-panel/dist/public");
  const frontendDestDir = path.resolve(distDir, "public");
  try {
    await access(frontendDist);
    console.log("copying frontend build → dist/public ...");
    await cp(frontendDist, frontendDestDir, { recursive: true });
    console.log("frontend copied ✓");
  } catch {
    console.warn("⚠ Frontend build not found at:", frontendDist, "— skipping copy");
    console.warn("  Run: pnpm --filter @workspace/smm-panel run build  first");
  }
}

buildAll().catch((err) => {
  console.error(err);
  process.exit(1);
});
