// SMM Panel Pro — cPanel Node.js Startup File
// Được tạo tự động — không chỉnh sửa
require('./dist/index.cjs');
